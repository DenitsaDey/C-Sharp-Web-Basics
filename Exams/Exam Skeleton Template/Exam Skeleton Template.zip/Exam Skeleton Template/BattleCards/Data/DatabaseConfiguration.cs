﻿namespace SulsApp.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=SULS;Trusted_Connection=True;Integrated Security=True;";
    }
}